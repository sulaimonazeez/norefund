<template>
  <div id="app">
    <router-view></router-view> <!-- This will display the matched component -->
  </div>
</template>

<script>
export default {
  name: 'App'
};
</script>

<style>
#app {
  font-family: Arial, sans-serif;
}
</style>
